<?php get_template_part('template-parts/header'); ?>

<section class="py-20 lg:py-28 bg-white relative overflow-hidden">
    <div class="relative max-w-7xl mx-auto px-6 lg:px-8">
        <div class="max-w-3xl">
            <span class="text-orange-600 font-bold tracking-widest uppercase text-sm mb-4 mt-4 block">Get In Touch</span>
            <h1 class="text-5xl md:text-6xl font-black tracking-tight text-slate-900 mb-6">
                Contact Our Team <br>
                <span class="text-transparent bg-clip-text bg-gradient-to-r from-orange-600 to-orange-400">We’re Here to Help</span>
            </h1>
            <p class="text-xl text-stone-900 leading-relaxed max-w-2xl">
                Have questions or want to learn more about our programs? Reach out to us and our team will get back to you as soon as possible.
            </p>
        </div>
    </div>
</section>


<div class="bg-white">
    <?php while ( have_posts() ) : the_post(); ?>

        <div class="max-w-3xl mx-auto bg-white rounded-3xl shadow-2xl p-10">
            <?php the_content(); // WordPress form shortcode outputs here ?>
        </div>
    <?php endwhile; ?>
</div>
    



<!-- Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&family=Poppins:wght@700&display=swap" rel="stylesheet">


<?php get_template_part('template-parts/footer'); ?>
