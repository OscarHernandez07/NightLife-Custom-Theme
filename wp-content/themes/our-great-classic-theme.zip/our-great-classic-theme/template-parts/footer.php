<body class="flex flex-col min-h-screen">

    <!-- Make main take all remaining space -->
    <main class="flex-grow">
        <!-- Your content goes here -->
    </main>

    <!-- Sticky Footer -->
    <footer class="bg-[#0B4B7F] text-slate-300 pt-20 pb-10 font-['Plus_Jakarta_Sans'] w-full mt-auto">
        <div class="container mx-auto px-6 max-w-7xl">
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
                <!-- Column 1 -->
                <div class="space-y-6">
                    <a href="/" class="text-3xl font-extrabold text-white tracking-tight">
                        NightLife<span class="text-blue-400">.</span>
                    </a>
                    <p class="text-sm font-medium leading-relaxed text-blue-100/80 max-w-xs">
                        Empowering the Worcester community through professional excellence and lifelong learning. Your gateway to career growth.
                    </p>
                    <div class="flex space-x-3 pt-2">
                        <a href="#" class="group w-10 h-10 bg-white/10 hover:bg-white rounded-xl flex items-center justify-center transition-all duration-300">
                            <!-- Facebook Icon -->
                        </a>
                        <a href="#" class="group w-10 h-10 bg-white/10 hover:bg-white rounded-xl flex items-center justify-center transition-all duration-300">
                            <!-- Twitter Icon -->
                        </a>
                    </div>
                </div>

                <!-- Column 2 -->
                <div class="ml-10">
                    <h3 class="text-sm font-bold uppercase tracking-widest text-white mb-7">Navigation</h3>
                    <ul class="space-y-4 font-medium">
                        <li><a href="/" class="text-blue-100/70 hover:text-white transition-colors duration-200 flex items-center group"><span class="w-0 group-hover:w-2 h-0.5 bg-blue-400 mr-0 group-hover:mr-2 transition-all"></span>Home</a></li>
                        <li><a href="<?php echo get_permalink(get_page_by_path( 'calendar' ) ); ?>" class="text-blue-100/70 hover:text-white transition-colors duration-200 flex items-center group"><span class="w-0 group-hover:w-2 h-0.5 bg-blue-400 mr-0 group-hover:mr-2 transition-all"></span>Calendar</a></li>
                        <li><a href="<?php echo get_permalink(get_page_by_path( 'teach') ); ?>" class="text-blue-100/70 hover:text-white transition-colors duration-200 flex items-center group"><span class="w-0 group-hover:w-2 h-0.5 bg-blue-400 mr-0 group-hover:mr-2 transition-all"></span>Teach For Us</a></li>
                        <li><a href="<?php echo get_permalink(get_page_by_path( 'contact-us')) ?>" class="text-blue-100/70 hover:text-white transition-colors duration-200 flex items-center group"><span class="w-0 group-hover:w-2 h-0.5 bg-blue-400 mr-0 group-hover:mr-2 transition-all"></span>Contact Us</a></li>
                    </ul>
                </div>

                <!-- Column 3 -->
                <div>
                    <h3 class="text-sm font-bold uppercase tracking-widest text-white mb-7">Resources</h3>
                    <ul class="space-y-4 font-medium">
                        <li><a href="/" class="text-blue-100/70 hover:text-white transition-colors duration-200 flex items-center group"><span class="w-0 group-hover:w-2 h-0.5 bg-blue-400 mr-0 group-hover:mr-2 transition-all"></span>Student Portal</a></li>
                        <li><a href="<?php echo get_permalink(get_page_by_path( 'calendar' ) ); ?>" class="text-blue-100/70 hover:text-white transition-colors duration-200 flex items-center group"><span class="w-0 group-hover:w-2 h-0.5 bg-blue-400 mr-0 group-hover:mr-2 transition-all"></span>Registration Info</a></li>
                    </ul>
                </div>

                <!-- Column 4 -->
                <div>
                    <h3 class="text-sm font-bold uppercase tracking-widest text-white mb-7">Get in Touch</h3>
                    <div class="space-y-4 font-medium">
                        <a href="mailto:sewardr@worcesterschools.net" class="flex items-start group">
                            <div class="mt-1 text-blue-400">
                                <!-- Email Icon -->
                            </div>
                            <span class="text-blue-100/70 group-hover:text-white transition-colors">sewardr@worcesterschools.net</span>
                        </a>
                        <div class="flex items-start">
                            <div class="mt-1 text-blue-400">
                                <!-- Phone Icon -->
                            </div>
                            <div class="text-blue-100/70">
                                <p>Office: 508-751-7612</p>
                                <p>Cell: 774-437-2788</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Footer Bottom -->
            <div class="pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-4 text-xs font-semibold uppercase tracking-widest text-blue-200/50">
                <p>&copy; 2026 NightLife. All rights reserved.</p>
                <p class="flex items-center">
                    Built for <span class="text-white ml-2">Worcester Public Schools</span>
                </p>
            </div>
        </div>
    </footer>
</body>
