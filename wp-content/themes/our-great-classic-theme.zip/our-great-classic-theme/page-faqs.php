<?php
/**
 * Template Name: FAQs & Policies Layout (No Search)
 */

get_template_part('template-parts/header');

// Get the specific page
$page = get_page_by_path('faqs');
$page_id = $page ? $page->ID : 0;
?>

<style>
    .faq-answer {
        max-height: 0;
        overflow: hidden;
        transition: max-height 0.3s ease-out, opacity 0.3s ease-out;
        opacity: 0;
    }
    .faq-answer.active {
        opacity: 1;
    }
    .faq-icon {
        transition: transform 0.3s ease;
    }
    .faq-trigger.active .faq-icon {
        transform: rotate(180deg);
    }
    html { scroll-behavior: smooth; }
</style>

<main class="bg-white min-h-screen">

    <?php if ($page): ?>

  <section class="pt-20 lg:pt-28 bg-white relative overflow-hidden">
    <div class="relative max-w-7xl mx-auto px-6 lg:px-8">
        <div class="max-w-3xl">
            <span class="text-orange-600 font-bold tracking-widest uppercase text-sm mb-4 mt-4 block">FAQs & Policies</span>
            <h1 class="text-5xl md:text-6xl font-black tracking-tight text-slate-900 mb-6">
                Everything You Need to Know <br>
                <span class="text-transparent bg-clip-text bg-gradient-to-r from-orange-600 to-orange-400">Guidelines & Answers</span>
            </h1>
            <p class="text-xl text-stone-900 leading-relaxed max-w-2xl">
                Find answers to common questions and review our policies to make the most of our programs. Everything you need to know is right here.
            </p>
        </div>
    </div>
</section>


    <section class="max-w-7xl mx-auto px-6 py-12 bg-white">
        <div class="flex flex-col lg:flex-row gap-12">

            <aside class="hidden lg:block">
                <div class="sticky top-10">
                    <h3 class="uppercase tracking-wider text-stone-900 text-xs font-bold mb-4">Table of Contents</h3>
                    <nav id="sidebar-nav" class="space-y-1 border-l-2 border-gray-100">
                        </nav>
                </div>
            </aside>

            <div class="lg:w-3/4">
                <div id="faq-content-area" class="prose prose-lg prose-blue max-w-none text-gray-600">
                    <?php 
                        // Output the content. The JS below will restructure it.
                        echo apply_filters('the_content', $page->post_content); 
                    ?>
                </div>
            </div>

        </div>
    </section>

    <?php else: ?>
        <section class="max-w-4xl mx-auto px-6 py-20 text-center">
            <h2 class="text-2xl font-bold text-gray-900">Page not found</h2>
            <p class="text-gray-600 mt-2">Please ensure you have created a page with the slug "faqs".</p>
        </section>
    <?php endif; ?>

</main>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const contentArea = document.getElementById('faq-content-area');
    if (!contentArea) return;

    // --- A. BUILD STICKY SIDEBAR ---
    const sidebarNav = document.getElementById('sidebar-nav');
    const sections = contentArea.querySelectorAll('h2'); // WP uses H2 for main sections usually
    
    if (sections.length > 0 && sidebarNav) {
        sections.forEach((section, index) => {
            // Give section an ID if it doesn't have one
            if (!section.id) {
                section.id = 'section-' + index;
            }
            
            // Create Link
            const link = document.createElement('a');
            link.href = '#' + section.id;
            link.className = 'block pl-4 py-2 text-sm text-gray-600 hover:text-blue-600 hover:border-l-2 hover:border-blue-600 border-l-2 border-transparent transition-all';
            link.innerText = section.innerText;
            sidebarNav.appendChild(link);
        });
    }

    // --- B. CONVERT H3 TO ACCORDIONS ---
    const questions = contentArea.querySelectorAll('h3');
    
    questions.forEach((question) => {
        // 1. Create wrapper for the question (the trigger)
        const trigger = document.createElement('button');
        trigger.className = 'faq-trigger w-full flex justify-between items-center text-left py-4 border-b border-gray-200 focus:outline-none group';
        trigger.innerHTML = `
            <span class="text-lg font-medium text-gray-900 group-hover:text-blue-600 transition-colors">${question.innerHTML}</span>
            <span class="ml-4 flex-shrink-0">
                <svg class="faq-icon w-5 h-5 text-gray-400 group-hover:text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                </svg>
            </span>
        `;

        // 2. Create wrapper for the answer (the hidden part)
        const answerDiv = document.createElement('div');
        answerDiv.className = 'faq-answer border-b border-gray-100 mb-4';
        
        // 3. Move all content between this H3 and the next H3 (or H2) into the answerDiv
        let nextNode = question.nextSibling;
        const nodesToMove = [];
        
        while (nextNode) {
            // Stop if we hit another Header (H2 or H3)
            if (nextNode.nodeType === 1 && (nextNode.tagName === 'H3' || nextNode.tagName === 'H2')) {
                break;
            }
            nodesToMove.push(nextNode);
            nextNode = nextNode.nextSibling;
        }

        // 4. Manipulate DOM
        question.parentNode.insertBefore(trigger, question); // Insert Trigger
        question.parentNode.insertBefore(answerDiv, question); // Insert Answer container
        
        // Move content into answer container
        nodesToMove.forEach(node => {
            answerDiv.appendChild(node);
        });
        
        // Remove old H3
        question.remove();

        // 5. Add Click Event
        trigger.addEventListener('click', () => {
            const isOpen = trigger.classList.contains('active');
            
            // Close all others
            document.querySelectorAll('.faq-trigger').forEach(t => {
                t.classList.remove('active');
                t.nextElementSibling.style.maxHeight = null;
                t.nextElementSibling.classList.remove('active');
            });

            if (!isOpen) {
                trigger.classList.add('active');
                answerDiv.classList.add('active');
                answerDiv.style.maxHeight = answerDiv.scrollHeight + "px";
            }
        });
    });
});
</script>

<?php get_template_part('template-parts/footer'); ?>