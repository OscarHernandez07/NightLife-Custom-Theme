<?php get_template_part('template-parts/header'); ?>

<?php
defined( 'ABSPATH' ) || exit;

wc_print_notices();
do_action( 'woocommerce_before_cart' );
?>

<div class="bg-white min-h-screen">
    
      <section class="pt-20 lg:pt-28 bg-white relative overflow-hidden">
    <div class="relative max-w-7xl mx-auto px-6 lg:px-8">
        <!-- Header Content -->
        <div class="max-w-3xl">
            <span class="text-orange-600 font-bold tracking-widest uppercase text-sm mb-4 mt-4 block">Your Cart</span>
            <h1 class="text-5xl md:text-6xl font-black tracking-tight text-slate-900 mb-6">
                Ready to Checkout <br>
                <span class="text-transparent bg-clip-text bg-gradient-to-r from-orange-600 to-orange-400">Review Your Items</span>
            </h1>
            <p class="text-xl text-stone-900 leading-relaxed max-w-2xl">
                Here’s a summary of the courses you’ve selected. You can update quantities, remove items, or proceed to checkout to start learning.
            </p>
        </div>
    </div>
  </section>



    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 md:py-20">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">

            <form class="woocommerce-cart-form lg:col-span-8" action="<?php echo esc_url( wc_get_cart_url() ); ?>" method="post">
                
                <div class="md:bg-white md:rounded-[2.5rem] md:border md:border-slate-200/60 md:overflow-hidden md:shadow-sm">
                    
                    <table class="shop_table shop_table_responsive w-full border-collapse block md:table">
                        
                        <thead class="hidden md:table-header-group bg-slate-50/50 text-left text-slate-500 text-xs uppercase tracking-[0.2em] font-bold">
                            <tr>
                                <th class="p-6 border-b border-slate-100">Course Selection</th>
                                <th class="p-6 border-b border-slate-100">Price</th>
                                <th class="p-6 border-b border-slate-100">Quantity</th>
                                <th class="p-6 border-b border-slate-100 text-right">Subtotal</th>
                            </tr>
                        </thead>

                        <tbody class="block md:table-row-group">
                            <?php foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) :
                                $_product   = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );
                                if ( $_product && $_product->exists() && $cart_item['quantity'] > 0 ) :
                                    $product_permalink = $_product->is_visible() ? $_product->get_permalink( $cart_item ) : '';
                            ?>
                            
                            <tr class="flex flex-col relative bg-white mb-6 rounded-3xl border border-slate-200 shadow-sm md:shadow-none md:border-none md:bg-transparent md:mb-0 md:table-row hover:bg-slate-50/30 transition-colors overflow-hidden">
                                
                                <td class="p-5 md:p-6 block md:table-cell w-full border-b border-slate-100 md:border-none">
                                    <div class="flex items-start md:items-center gap-4 md:gap-6">
                                        <div class="w-20 h-20 md:w-20 md:h-20 rounded-2xl overflow-hidden shrink-0 border border-slate-100 shadow-sm bg-slate-100">
                                            <?php echo $_product->get_image( 'thumbnail', ['class' => 'w-full h-full object-cover'] ); ?>
                                        </div>
                                        
                                        <div class="flex-1">
                                            <a href="<?php echo $product_permalink; ?>" class="text-lg font-black text-slate-900 hover:text-orange-600 transition-colors block mb-1 leading-tight">
                                                <?php echo $_product->get_name(); ?>
                                            </a>
                                            
                                            <div class="md:hidden text-slate-500 font-bold text-sm mb-2">
                                                <?php echo wc_price( $_product->get_price() ); ?>
                                            </div>

                                            <div class="text-xs text-slate-500">
                                                <?php echo wc_get_formatted_cart_item_data( $cart_item ); ?>
                                            </div>
                                            
                                            <div class="mt-2">
                                                <?php
                                                echo apply_filters( 'woocommerce_cart_item_remove_link', sprintf(
                                                    '<a href="%s" class="inline-flex items-center gap-1 text-slate-400 text-[10px] md:text-xs font-bold uppercase tracking-wider hover:text-red-500 transition-colors">
                                                        <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
                                                        Remove
                                                    </a>',
                                                    esc_url( wc_get_cart_remove_url( $cart_item_key ) )
                                                ), $cart_item_key );
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                </td>

                                <td class="hidden md:table-cell p-6 text-slate-600 font-medium">
                                    <?php echo wc_price( $_product->get_price() ); ?>
                                </td>

                                <td class="p-5 md:p-6 block md:table-cell border-b border-slate-100 md:border-none">
                                    <div class="md:hidden text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Quantity</div>
                                    
                                    <div class="max-w-[100px] md:max-w-none [&_input]:rounded-xl [&_input]:border-slate-200 [&_input]:font-bold [&_input]:w-full [&_input]:h-10">
                                        <?php
                                        woocommerce_quantity_input( array(
                                            'input_name'  => "cart[{$cart_item_key}][qty]",
                                            'input_value' => $cart_item['quantity'],
                                            'min_value'   => 0,
                                            'max_value'   => $_product->get_max_purchase_quantity(),
                                        ), $_product );
                                        ?>
                                    </div>
                                </td>

                                <td class="p-5 md:p-6 block md:table-cell md:text-right bg-slate-50 md:bg-transparent">
                                    <div class="flex justify-between items-center md:block">
                                        <span class="md:hidden text-xs font-bold text-slate-400 uppercase tracking-wider">Total:</span>
                                        <span class="font-black text-slate-900 text-lg">
                                            <?php echo WC()->cart->get_product_subtotal( $_product, $cart_item['quantity'] ); ?>
                                        </span>
                                    </div>
                                </td>
                            </tr>
                            <?php endif; endforeach; ?>
                        </tbody>
                    </table>

                    <div class="p-6 bg-slate-50/50 flex flex-col md:flex-row md:items-center justify-between gap-4 rounded-3xl md:rounded-none mt-4 md:mt-0">
                        <div class="coupon w-full md:w-auto flex gap-2">
                            <input type="text" name="coupon_code" class="flex-1 px-5 py-3 rounded-xl border border-slate-200 focus:border-orange-500 focus:ring-0 text-sm transition-all bg-white" placeholder="Coupon code" />
                            <button type="submit" name="apply_coupon" class="bg-white border border-slate-200 text-slate-900 px-6 py-3 rounded-xl font-bold text-sm hover:bg-slate-100 transition shadow-sm whitespace-nowrap">Apply</button>
                        </div>
                        
                        <button type="submit" name="update_cart" class="w-full md:w-auto bg-slate-900 text-white px-8 py-3 rounded-xl font-bold text-sm hover:bg-orange-600 transition-all transform hover:-translate-y-0.5 shadow-lg shadow-slate-900/10">
                            Update Cart
                        </button>
                        <?php wp_nonce_field( 'woocommerce-cart', 'woocommerce-cart-nonce' ); ?>
                    </div>
                </div>
            </form>

            <div class="lg:col-span-4 sticky top-8">
                <div class="bg-white rounded-[2rem] border border-slate-200 shadow-xl shadow-slate-200/40 p-6 md:p-10 relative overflow-hidden">
                    <div class="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-orange-600 to-orange-400"></div>

                    <h2 class="text-xl md:text-2xl font-black text-slate-900 mb-6 md:mb-8 uppercase tracking-tight">Summary</h2>

                    <div class="space-y-4 text-sm md:text-base">
                        <?php woocommerce_cart_totals(); ?>
                    </div>

                    <div class="mt-8 md:mt-10">
                        <a href="<?php echo wc_get_checkout_url(); ?>"
                           class="block w-full text-center bg-orange-600 text-white font-black py-4 md:py-5 rounded-2xl text-base md:text-lg hover:bg-orange-500 transition-all shadow-lg shadow-orange-600/30 transform hover:-translate-y-1">
                            Secure Checkout &rarr;
                        </a>
                        <p class="text-center text-slate-400 text-[10px] md:text-xs mt-4 md:mt-6 font-medium tracking-wide">
                            <svg class="w-3 h-3 inline-block mr-1 -mt-0.5" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clip-rule="evenodd"/></svg>
                            SECURE SSL ENCRYPTED PAYMENT
                        </p>
                    </div>
                </div>
                
                <div class="mt-6 md:mt-8 bg-[rgb(229,230,230)] rounded-3xl p-6 border border-slate-200/60 text-center">
                    <p class="text-slate-600 text-sm font-medium">Need help with your enrollment?</p>
                    <a href="/contact" class="text-orange-600 font-bold text-sm hover:underline">Chat with an advisor</a>
                </div>
            </div>

        </div>
    </div>
</div>

<?php get_template_part('template-parts/footer'); ?>