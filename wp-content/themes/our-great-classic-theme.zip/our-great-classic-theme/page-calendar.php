<?php 
/* Template Name: Modern Events Calendar */
get_template_part('template-parts/header'); 
?>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.css">

<?php
$calendar_page = get_page_by_path('calendar');
$events = [];

$event_posts = get_posts([
    'post_type'      => 'post',
    'posts_per_page' => -1,
    'meta_key'       => 'event_date',
    'orderby'        => 'meta_value',
    'order'          => 'ASC',
]);

foreach ($event_posts as $post) {
    $date = get_post_meta($post->ID, 'event_date', true);
    if ($date) {
        $events[] = [
            'title' => $post->post_title,
            'start' => $date,
            'url'   => get_permalink($post->ID),
            'className' => 'modern-event-pill' // Custom class for styling
        ];
    }
}
?>

<section class="pt-20 lg:pt-28 bg-white relative overflow-hidden">
    <div class="relative max-w-7xl mx-auto px-6 lg:px-8">
        <div class="max-w-3xl">
            <span class="text-orange-600 font-bold tracking-widest uppercase text-sm mb-4 mt-4 block">Calendar & Events</span>
            <h1 class="text-5xl md:text-6xl font-black tracking-tight text-slate-900 mb-6">
                Stay on Track <br>
                <span class="text-transparent bg-clip-text bg-gradient-to-r from-orange-600 to-orange-400">All Upcoming Events</span>
            </h1>
            <p class="text-xl text-stone-900 leading-relaxed max-w-2xl">
                Keep up with all our upcoming programs, workshops, and important dates. Plan ahead and never miss an event.
            </p>
        </div>
    </div>
</section>


<main class="bg-white min-h-screen py-20 font-sans">
    <div class="max-w-6xl mx-auto px-6">

        <div class="bg-white rounded-[32px] shadow-[0_20px_50px_rgba(0,0,0,0.05)] border border-slate-100 overflow-hidden">
            <div class="p-6 md:p-10">
                <div id="pro-calendar"></div>
            </div>
            
            <div class="bg-slate-50 border-t border-slate-100 px-10 py-6 flex flex-wrap items-center justify-between gap-4">
                <div class="flex items-center gap-6">
                    <div class="flex items-center gap-2">
                        <span class="w-3 h-3 bg-blue-600 rounded-full"></span>
                        <span class="text-sm font-semibold text-slate-600">Events</span>
                    </div>
                    <div class="flex items-center gap-2">
                        <span class="w-3 h-3 bg-blue-100 border border-blue-400 rounded-full"></span>
                        <span class="text-sm font-semibold text-slate-600">Today</span>
                    </div>
                </div>
                <p class="text-xs text-slate-400 font-medium italic">Click on an event to view full details</p>
            </div>
        </div>
    </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const calendarEl = document.getElementById('pro-calendar');
    const calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek'
        },
        buttonText: {
            today: 'Today',
            month: 'Month',
            week: 'Week'
        },
        height: 'auto',
        dayMaxEvents: true,
        events: <?php echo json_encode($events); ?>,
        eventClick: function(info) {
            info.jsEvent.preventDefault();
            if (info.event.url) {
                window.open(info.event.url, '_blank');
            }
        }
    });
    calendar.render();
});
</script>

<style>
    /* 1. Global Calendar Styling */
    :root {
        --fc-border-color: #f1f5f9;
        --fc-button-bg-color: #ffffff;
        --fc-button-border-color: #e2e8f0;
        --fc-button-text-color: #64748b;
        --fc-button-hover-bg-color: #f8fafc;
        --fc-button-active-bg-color: #2563eb;
    }

    /* Toolbar Title */
    .fc .fc-toolbar-title {
        font-size: 1.5rem !important;
        font-weight: 800 !important;
        color: #0f172a;
        letter-spacing: -0.025em;
    }

    /* Buttons */
    .fc .fc-button {
        text-transform: capitalize;
        font-weight: 600 !important;
        font-size: 0.875rem !important;
        border-radius: 12px !important;
        padding: 8px 16px !important;
        box-shadow: 0 1px 2px rgba(0,0,0,0.05);
        transition: all 0.2s ease;
    }

    .fc .fc-button-primary:not(:disabled).fc-button-active, 
    .fc .fc-button-primary:not(:disabled):active {
        background-color: #2563eb !important;
        border-color: #2563eb !important;
        color: white !important;
    }

    /* Table Grid Styling */
    .fc-theme-standard td, .fc-theme-standard th {
        border: 1px solid #f1f5f9 !important;
    }

    .fc .fc-col-header-cell-cushion {
        padding: 15px 0 !important;
        color: #94a3b8 !important;
        font-size: 0.75rem !important;
        text-transform: uppercase;
        letter-spacing: 0.1em;
        font-weight: 700;
    }

    /* Event Pill Styling */
    .modern-event-pill {
        background: #2563eb !important;
        border: none !important;
        border-radius: 8px !important;
        padding: 4px 10px !important;
        font-size: 0.75rem !important;
        font-weight: 600 !important;
        margin: 2px 4px !important;
        transition: transform 0.2s ease, box-shadow 0.2s ease !important;
        cursor: pointer;
    }

    .modern-event-pill:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(37, 99, 235, 0.3);
        background: #1d4ed8 !important;
    }

    /* Day Number Styling */
    .fc .fc-daygrid-day-number {
        font-family: 'Inter', sans-serif;
        font-weight: 500;
        color: #64748b;
        padding: 10px !important;
    }

    /* Today's Highlight */
    .fc .fc-day-today {
        background: rgba(37, 99, 235, 0.03) !important;
    }
    
    .fc .fc-day-today .fc-daygrid-day-number {
        background: #2563eb;
        color: white !important;
        border-radius: 8px;
        margin: 8px;
        padding: 4px 8px !important;
    }

    /* Mobile responsiveness */
    @media (max-width: 768px) {
        .fc .fc-toolbar {
            flex-direction: column;
            gap: 1rem;
        }
        .fc .fc-toolbar-title { font-size: 1.25rem !important; }
    }
</style>

<?php get_template_part('template-parts/footer'); ?>


